# CHANGELOG.md

## [2.0.0] - 2025-02-04

- Upgrade to Tailwind 4
- Update other dependencies

## [1.4.0] - 2024-12-08

- Update dependencies + Upgrade to Next.js 15

## [1.3.2] - 2024-10-21

- Update dependencies
- Fix issue with Transition component

## [1.3.0] - 2024-07-05

- Replace Contentlayer with MDX

## [1.2.0] - 2023-12-07

- Update Next.js to 14

## [1.1.2] - 2023-10-04

- Update Twitter icon
- Update dependencies

## [1.1.0] - 2023-05-06

- Update dependencies
- Improve modal video component

## [1.0.0] - 2023-04-11

First release