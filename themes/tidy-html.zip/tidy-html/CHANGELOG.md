# CHANGELOG.md

## [2.0.0] - 2025-02-04

- Upgrade to Tailwind 4
- Update other dependencies

## [1.2.5] - 2023-12-07

- Update dependencies

## [1.2.4] - 2023-10-04

- Update Twitter icon
- Update dependencies

## [1.2.2] - 2023-05-06

- Dependencies update

## [1.2.1] - 2023-04-11

- Tailwind dependency update (v3.3)

## [1.2.0] - 2023-03-28

- Update video modal
- Minor changes and fixes
- Dependency updates

## [1.1.1] - 2023-02-10

- Minor changes
- JS library updates

## [1.1.0] - 2022-07-15

- Remove Webpack

## [1.0.0] - 2022-01-12

First release
